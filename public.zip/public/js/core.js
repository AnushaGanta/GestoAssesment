angular.module('gestoFood', ['foodController', 'foodService']);
